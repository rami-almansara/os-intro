#!/bin/bash
mkdir ~/backup
cp lab12_1.sh  ~/backup/backup.sh
gzip ~/backup/backup.sh